import random, statistics, json
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
FPS=30; FRAMES=150; PPF=20; OWD=0.025; RTT=2*OWD; RTO=0.2
GAP=(1/FPS)/PPF
def run(p, rng, proto):
    arr=[]  # arrival time per packet
    lost_flags=[]
    for f in range(FRAMES):
        for k in range(PPF):
            s=f/FPS+k*GAP
            if proto=="udp":
                lost=rng.random()<p
                arr.append(None if lost else s+OWD); lost_flags.append(lost)
            else:
                t=s; rto=RTO; first=True
                while True:
                    if rng.random()>=p:
                        arr.append(t+OWD); break
                    # lost: fast retransmit (3 dup ACKs) first time, RTO afterwards
                    wait = 3*GAP+RTT if first else rto
                    first=False; rto*=2
                    t=t+wait
                lost_flags.append(False)
    return arr,lost_flags
def metrics(p, proto, runs=300, seed=1):
    rng=random.Random(seed)
    lat=[];p95=[];late=[];dmg=[]
    for _ in range(runs):
        arr,lost=run(p,rng,proto)
        fl=[];bad=0;late_n=0
        if proto=="udp":
            for f in range(FRAMES):
                seg=slice(f*PPF,(f+1)*PPF)
                if any(lost[seg]): bad+=1
                got=[a for a in arr[seg] if a is not None]
                fl.append((max(got) if got else f/FPS+OWD)-f/FPS)
            dmg.append(100*bad/FRAMES); late.append(0)
        else:
            run_max=0
            for f in range(FRAMES):
                for k in range(PPF):
                    run_max=max(run_max,arr[f*PPF+k])
                    last=run_max
                fl.append(last-f/FPS)
            n=sum(1 for x in fl if x>0.2)
            late.append(100*n/FRAMES); dmg.append(0)
        lat.append(statistics.mean(fl)*1000)
        fs=sorted(fl); p95.append(fs[int(.95*len(fs))-1]*1000)
    m=lambda x: round(statistics.mean(x),2)
    return dict(lat=m(lat),p95=m(p95),late=m(late),dmg=m(dmg))
res={}
for p in [0,0.01,0.02,0.05,0.10]:
    res[p]={"tcp":metrics(p,"tcp"),"udp":metrics(p,"udp")}
json.dump(res,open("results.json","w"),indent=1)
for p,v in res.items(): print(p,v)
ps=[int(p*100) for p in res]
C_T="#1f4e79"; C_U="#c55a11"
plt.rcParams.update({"font.family":"DejaVu Serif","font.size":10})
fig,ax=plt.subplots(figsize=(6.4,3.6))
ax.plot(ps,[res[p]["tcp"]["lat"] for p in res],"o-",color=C_T,label="TCP mean")
ax.plot(ps,[res[p]["tcp"]["p95"] for p in res],"s--",color=C_T,label="TCP 95th percentile")
ax.plot(ps,[res[p]["udp"]["lat"] for p in res],"o-",color=C_U,label="UDP mean")
ax.plot(ps,[res[p]["udp"]["p95"] for p in res],"s--",color=C_U,label="UDP 95th percentile")
ax.set_xlabel("Packet loss (%)"); ax.set_ylabel("Frame delivery delay (ms)")
ax.set_title("Frame delivery delay vs packet loss"); ax.grid(alpha=.3); ax.legend(frameon=False,fontsize=8)
for s in ("top","right"): ax.spines[s].set_visible(False)
fig.tight_layout(); fig.savefig("fig_delay.png",dpi=200); plt.close()
fig,ax=plt.subplots(figsize=(6.4,3.6))
import numpy as np
x=np.arange(len(ps)); w=.38
b1=ax.bar(x-w/2,[res[p]["tcp"]["late"] for p in res],w,color=C_T,label="TCP: frames later than 200 ms live deadline")
b2=ax.bar(x+w/2,[res[p]["udp"]["dmg"] for p in res],w,color=C_U,label="UDP: frames with missing data")
ax.set_xticks(x); ax.set_xticklabels([f"{v}%" for v in ps]); ax.set_xlabel("Packet loss"); ax.set_ylabel("Frames affected (%)")
ax.set_title("Cost of loss: lateness (TCP) vs damage (UDP)")
for b in list(b1)+list(b2):
    ax.text(b.get_x()+b.get_width()/2,b.get_height()+1,f"{b.get_height():.0f}",ha="center",fontsize=8)
ax.legend(frameon=False,fontsize=8,loc="upper left"); ax.set_ylim(0,115)
for s in ("top","right"): ax.spines[s].set_visible(False)
fig.tight_layout(); fig.savefig("fig_frames.png",dpi=200); plt.close()
# diagrams
from matplotlib.patches import FancyBboxPatch
def box(ax,x,y,w,h,t,c,tc="white",fs=9):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.02,rounding_size=0.05",fc=c,ec="none"))
    ax.text(x+w/2,y+h/2,t,ha="center",va="center",color=tc,fontsize=fs)
fig,ax=plt.subplots(figsize=(6.6,3.4)); ax.axis("off"); ax.set_xlim(0,10); ax.set_ylim(0,5)
ax.text(2.4,4.7,"On-demand (Netflix, YouTube)",ha="center",fontweight="bold",fontsize=9)
ax.text(7.6,4.7,"Live / interactive (WebRTC, calls)",ha="center",fontweight="bold",fontsize=9)
for xo,layers in ((0.4,[("HLS / MPEG-DASH","#2e75b6"),("HTTP/1.1, HTTP/2","#2e75b6"),("TCP (or QUIC)","#1f4e79"),("IP","#595959")]),(5.6,[("RTP / SRTP + RTCP","#e08a3c"),("DTLS-SRTP, ICE","#e08a3c"),("UDP","#c55a11"),("IP","#595959")])):
    for i,(t,c) in enumerate(layers): box(ax,xo,3.4-i*0.95,4.0,0.8,t,c)
ax.text(5,0.1,"Application layer on top, transport layer in the middle",ha="center",fontsize=8,style="italic",color="#444")
fig.tight_layout(); fig.savefig("fig_stack.png",dpi=200); plt.close()
fig,ax=plt.subplots(figsize=(6.6,3.4)); ax.axis("off"); ax.set_xlim(0,10); ax.set_ylim(0,5)
box(ax,0.2,1.9,1.7,1.2,"Camera /\nsource video",  "#595959")
box(ax,2.4,1.9,1.7,1.2,"Encoder\n(H.264/H.265)","#2e75b6")
box(ax,4.6,1.9,1.7,1.2,"Segmenter /\nCDN origin","#2e75b6")
box(ax,6.8,1.9,1.3,1.2,"CDN\nedge","#1f4e79")
box(ax,8.5,1.9,1.3,1.2,"Player\nbuffer","#c55a11")
for x0,x1 in ((1.9,2.4),(4.1,4.6),(6.3,6.8),(8.1,8.5)):
    ax.annotate("",xy=(x1,2.5),xytext=(x0,2.5),arrowprops=dict(arrowstyle="->",color="#333"))
ax.text(7.45,1.3,"HTTP over TCP/QUIC\n(segments, ABR)",ha="center",fontsize=8,color="#1f4e79")
ax.text(5.0,4.1,"Adaptive-bitrate pipeline: the player chooses the next segment quality from measured throughput",ha="center",fontsize=8.5)
fig.tight_layout(); fig.savefig("fig_pipeline.png",dpi=200); plt.close()
# handshake
fig,ax=plt.subplots(figsize=(6.6,3.6)); ax.axis("off"); ax.set_xlim(0,10); ax.set_ylim(0,6)
for x,t in ((2,"Client"),(8,"Server")):
    ax.text(x,5.7,t,ha="center",fontweight="bold"); ax.plot([x,x],[0.3,5.4],color="#444")
steps=[("SYN",5.0,1),("SYN-ACK",4.0,-1),("ACK",3.0,1),("HTTP GET segment",2.1,1),("Data + ACKs",1.2,-1)]
for t,y,d in steps:
    a,b=(2,8) if d==1 else (8,2)
    ax.annotate("",xy=(b,y-0.35),xytext=(a,y),arrowprops=dict(arrowstyle="->",color="#1f4e79"))
    ax.text(5,y+0.05,t,ha="center",fontsize=8.5,color="#1f4e79")
ax.text(9.1,3.9,"UDP: no\nhandshake,\nfirst packet\nis data",fontsize=8,color="#c55a11",va="center")
fig.tight_layout(); fig.savefig("fig_hs.png",dpi=200); plt.close()
