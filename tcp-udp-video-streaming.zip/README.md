# TCP vs UDP: A Case Study of Network Protocols in Video Streaming

CIA Activity - PCCO302 Computer Network, Computer Engineering (TY, Sem 5)
Sanjivani College of Engineering, Kopargaon

## About
Simulation of a 30 fps video stream under packet loss (0-10%) comparing TCP-style
(reliable, in-order, retransmission) and UDP-style (no retransmission) delivery.
It measures frame delivery delay and the share of late (TCP) or damaged (UDP) frames.

## Files
- `tcp_udp_simulation.py` - simulation and chart generation (Python 3, matplotlib, numpy)
- `results/` - results.json and generated charts/diagrams
- `report/` - the full CIA activity report (.docx)

## Run
```
pip install matplotlib numpy
python tcp_udp_simulation.py
```

## Team
Group ID: ____    Members: ____
